#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

#include <assimp/Importer.hpp>      
#include <assimp/scene.h>           
#include <assimp/postprocess.h> 

#include <iostream>

#include "Material.h"

Material::Material() {

}
Material::~Material() {}

glm::vec3 Material::getAmbient() {
	return ambient;
}
glm::vec3 Material::getDiffuse() {
	return diffuse;
}
glm::vec3 Material::getSpecular() {
	return specular;
}
glm::vec3 Material::getEmissive() {
	return emissive;
}

void Material::setAmbient(glm::vec3 ambient) {
	this->ambient = ambient;
}
void Material::setDiffuse(glm::vec3 diffuse) {
	this->diffuse = diffuse;
}
void Material::setSpecular(glm::vec3 specular) {
	this->specular = specular;
}
void Material::setEmissive(glm::vec3 emissive) {
	this->emissive = emissive;
}