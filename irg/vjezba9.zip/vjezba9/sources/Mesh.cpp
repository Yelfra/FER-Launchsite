#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

#include <assimp/Importer.hpp>      
#include <assimp/scene.h>           
#include <assimp/postprocess.h> 

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <iostream>

#include "Mesh.h"

Mesh::Mesh(char* path, Material* material, Texture* texture) {
	this->path = path;
	boundingBox.reserve(6);

	loadMesh(material, texture);
	setupBuffers();
}
Mesh::~Mesh() {
	// Deleting VAO, VBO, EBO
	glDeleteBuffers(1, &EBO);
	glDeleteBuffers(1, &VBO_normal);
	glDeleteBuffers(1, &VBO_vertex);
	glDeleteBuffers(1, &VBO_texture);
	glDeleteVertexArrays(1, &VAO);
}

void Mesh::setupBuffers() {
	// Generating VAO, VBO, EBO
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO_vertex);
	glGenBuffers(1, &VBO_normal);
	glGenBuffers(1, &VBO_texture);
	glGenBuffers(1, &EBO);

	updateBuffers();
}

void Mesh::updateBuffers() {
	// Passing data to buffers
	glBindVertexArray(VAO);
		glBindBuffer(GL_ARRAY_BUFFER, VBO_vertex);
		glBufferData(GL_ARRAY_BUFFER, sizeof(float) * getVerticesNum(), &vertices[0], GL_STATIC_DRAW);
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
		
		glBindBuffer(GL_ARRAY_BUFFER, VBO_normal);
		glBufferData(GL_ARRAY_BUFFER, sizeof(float) * getNormalsNum(), &vertex_normals[0], GL_STATIC_DRAW);
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

		glBindBuffer(GL_ARRAY_BUFFER, VBO_texture);
		glBufferData(GL_ARRAY_BUFFER, sizeof(float) * getTexturesNum(), &vertex_textures[0], GL_STATIC_DRAW);
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);

		glEnableVertexAttribArray(0);
		glEnableVertexAttribArray(1);
		glEnableVertexAttribArray(2);

		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int) * getIndicesNum(), (void*)(&vertex_indices[0]), GL_STATIC_DRAW);
	glBindVertexArray(0);
}

void Mesh::loadMesh(Material* material, Texture* texture) {
	// Loading with Assimp
	Assimp::Importer importer;

	std::string dirPath(path, 0, path.find_last_of("\\/"));
	std::string resPath(dirPath);
	resPath.append("\\resources");
	std::string objPath(resPath);
	objPath.append("\\glava\\glava.obj");

	const aiScene* scene = importer.ReadFile(objPath.c_str(),
											 aiProcess_CalcTangentSpace |
											 aiProcess_Triangulate |
											 aiProcess_JoinIdenticalVertices |
											 aiProcess_SortByPType |
											 aiProcess_FlipUVs);
	if(!scene) {
		std::cerr << importer.GetErrorString();
		return;
	}

	// Processing loaded meshes
	if(scene->HasMeshes()) {
		aiMesh* mesh = scene->mMeshes[0];

		std::cout << "Loading polygon mesh..." << std::endl;

		float x, y, z;
		float x_min = std::numeric_limits<float>::max(), x_max = std::numeric_limits<float>::min();
		float y_min = std::numeric_limits<float>::max(), y_max = std::numeric_limits<float>::min();
		float z_min = std::numeric_limits<float>::max(), z_max = std::numeric_limits<float>::min();

		for(int i = 0; i < mesh->mNumVertices; i++) {
			x = mesh->mVertices[i].x;
			y = mesh->mVertices[i].y;
			z = mesh->mVertices[i].z;

			if(x < x_min) x_min = x; if(x > x_max) x_max = x;
			if(y < y_min) y_min = y; if(y > y_max) y_max = y;
			if(z < z_min) z_min = z; if(z > z_max) z_max = z;
		}
		boundingBox.push_back(x_min);	boundingBox.push_back(x_max);
		boundingBox.push_back(y_min);	boundingBox.push_back(y_max);
		boundingBox.push_back(z_min);	boundingBox.push_back(z_max);
		
		float x_average = (x_min + x_max) / 2;
		float y_average = (y_min + y_max) / 2;
		float z_average = (z_min + z_max) / 2;

		float M = std::max({ x_max - x_min, y_max - y_min, z_max - z_min });
		
		for(int i = 0; i < mesh->mNumVertices; i++) {
			aiVector3D vertex = mesh->mVertices[i];
			x = (vertex.x - x_average) * 2 / M / 1.5f; // mesh->mVertices[i].x;
			y = (vertex.y - y_average) * 2 / M; // mesh->mVertices[i].y; 
			z = (vertex.z - z_average) * 2 / M; // mesh->mVertices[i].z;
			
			vertices.push_back(x);
			vertices.push_back(y);
			vertices.push_back(z);
			
			aiVector3D normal = mesh->mNormals[i];
			vertex_normals.push_back(normal.x);
			vertex_normals.push_back(normal.y);
			vertex_normals.push_back(normal.z);

			aiVector3D texture = mesh->mTextureCoords[0][i];
			vertex_textures.push_back(texture.x);
			vertex_textures.push_back(texture.y);
			//vertex_textures.push_back(texture.z);
		}
		
		for(int i = 0; i < mesh->mNumFaces; i++) {
			for(int j = 0; j < mesh->mFaces[i].mNumIndices; j++) {
				int vertex = mesh->mFaces[i].mIndices[j];
				vertex_indices.push_back(vertex);
			}
		}

		std::cout << "Mesh successfully loaded." << std::endl;
	}

	if(scene->HasMaterials()) {
		std::cout << "Loading material properties..." << std::endl;

		for(int i = 1; i < scene->mNumMaterials; i++) {

			aiString texturePosition;
			int width, height, nrChannels;
			unsigned char* data;
			if(AI_SUCCESS == scene->mMaterials[i]->Get(AI_MATKEY_TEXTURE(aiTextureType_DIFFUSE, 0), texturePosition)) {
				//std::cout << texturePosition.C_Str() << std::endl;
				std::string texPath(resPath);
				texPath.append("\\glava\\");
				texPath.append(texturePosition.C_Str());

				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

				data = stbi_load(texPath.c_str(), &width, &height, &nrChannels, 0);
				if(!data) {
					std::cerr << "Failed to load texture: " << texPath << std::endl;
				} else {

					texture->setupTexture(data, width, height, nrChannels);

					//glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
					//glGenerateMipmap(GL_TEXTURE_2D);

					// Set texture parameters if needed
					//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
					//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
					//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
					//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
					//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

					//if(nrChannels == 3)
					//	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
					//else if(nrChannels == 4)
					//	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);



					// Bind the texture to a texture unit
					//GLuint textureUnit = 0; // Use texture unit 0 for simplicity
					//glActiveTexture(GL_TEXTURE0 + textureUnit);
					//glBindTexture(GL_TEXTURE_2D, texture);

					//GLuint textureSamplerLocation = glGetUniformLocation(shaderProgram, "textureSampler");
					//glUniform1i(textureSamplerLocation, textureUnit);
				}
				stbi_image_free(data);
			}

			glm::vec3 ambientColor;
			aiColor3D ambientK, diffuseK, specularK, reflectiveK, emissiveK;

			std::cout << "ambient: ";
			scene->mMaterials[i]->Get(AI_MATKEY_COLOR_AMBIENT, ambientK);
			material->setAmbient(glm::vec3(ambientK.r, ambientK.g, ambientK.b));
			std::cout << ambientK.r << " " << ambientK.g << " " << ambientK.b << std::endl;

			std::cout << "diffuse: ";
			scene->mMaterials[i]->Get(AI_MATKEY_COLOR_DIFFUSE, diffuseK);
			material->setDiffuse(glm::vec3(diffuseK.r, diffuseK.g, diffuseK.b));
			std::cout << diffuseK.r << " " << diffuseK.g << " " << diffuseK.b << std::endl;

			std::cout << "specular: ";
			scene->mMaterials[i]->Get(AI_MATKEY_COLOR_SPECULAR, specularK);
			material->setSpecular(glm::vec3(specularK.r, specularK.g, specularK.b));
			std::cout << specularK.r << " " << specularK.g << " " << specularK.b << std::endl;


			std::cout << "emissive: ";
			scene->mMaterials[i]->Get(AI_MATKEY_COLOR_EMISSIVE, emissiveK);
			material->setEmissive(glm::vec3(emissiveK.r, emissiveK.g, emissiveK.b));
			std::cout << emissiveK.r << " " << emissiveK.g << " " << emissiveK.b << std::endl;
		}

	}
}

std::vector<float> Mesh::getBoundingBox() {
	return boundingBox;
}

std::vector<float> Mesh::getVertices() {
	return vertices;
}
unsigned int Mesh::getVerticesNum() {
	return vertices.size();
}

std::vector<unsigned int> Mesh::getIndices() {
	return vertex_indices;
}
unsigned int Mesh::getIndicesNum() {
	return vertex_indices.size();
}

std::vector<float> Mesh::getNormals() {
	return vertex_normals;
}
unsigned int Mesh::getNormalsNum() {
	return vertex_normals.size();
}

std::vector<float> Mesh::getTextures() {
	return vertex_textures;
}
unsigned int Mesh::getTexturesNum() {
	return vertex_textures.size();
}