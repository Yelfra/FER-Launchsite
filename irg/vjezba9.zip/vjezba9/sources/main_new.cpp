// Local Headers
#include "Shader_new.h"
#include "Mesh.h"
#include "Camera.h"

// System Headers
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h> 

// Standard Headers
#include <iostream>
#include <cstdlib>
#include <vector>

// Window width & height
unsigned int window_width = 1280;
unsigned int window_height = 800;

void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
	window_width = width;
	window_height = height;

	// Update viewport
	glViewport(0, 0, width, height);
}

int main(int argc, char * argv[]) {
	/*********************************************************************************************/
	// Initializing GLFW
	glfwInit();

	//glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	//glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
	//glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	//glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	
	// Initializing Window
	GLFWwindow* window = glfwCreateWindow(window_width, window_height, "9", nullptr, nullptr);
	if(window == nullptr) {
		std::cout << stderr << "Failed to Create Window, OpenGL Context" << std::endl;
		exit(EXIT_FAILURE);
	}
	glfwMakeContextCurrent(window);

	// Loading configurations for OpenGL with glad
	gladLoadGL();

	// VSYNC
	glfwSwapInterval(0);
	// Adjusting window dimensions when changed
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

	// Setting up the background colour of newly loaded frames
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

	// Enabling Z-buffers
	glEnable(GL_DEPTH_TEST);
	// Enabling face culling
	glEnable(GL_CULL_FACE);

	/*********************************************************************************************/
	// Setting up Shader
	Shader* shader = new Shader(argv[0], "shader");

	// Setting up Camera
	Camera* camera = new Camera(window_width, window_height, glm::vec3(0.0f, 0.0f, 2.0f));

		// Setting up uniform variables
		//GLint uniformLocation_modelMatrix = glGetUniformLocation(shader->ID, "modelMatrix");
		//GLint uniformLocation_viewMatrix = glGetUniformLocation(shader->ID, "viewMatrix");
		//GLint uniformLocation_projectionMatrix = glGetUniformLocation(shader->ID, "projectionMatrix");
		//
		//glm::mat4 identityMatrix = glm::mat4(1);
		//glm::mat4 modelMatrix = identityMatrix;
		//glm::mat4 viewMatrix = identityMatrix;
		//glm::mat4 projectionMatrix = identityMatrix;

		//viewMatrix = glm::translate(viewMatrix, glm::vec3(0.0f, 0.0f, -5.0f));
		//projectionMatrix = glm::perspective(glm::radians(45.0f), static_cast<float>(window_width / window_height), 0.1f, 100.0f);

	/*********************************************************************************************/
	// Setting up Material
	Material* material = new Material();
	// Setting up Texture
	Texture* texture = new Texture();
	// Setting up Mesh
	Mesh* mesh = new Mesh(argv[0], material, texture);

	// Calling shader
	glUseProgram(shader->ID);
	
	// Set up uniform variables for lighting
	glm::vec3 ambient = material->getAmbient();
	glUniform3f(glGetUniformLocation(shader->ID, "ambient"), ambient.r, ambient.g, ambient.b);
	glm::vec3 diffuse = material->getDiffuse();
	glUniform3f(glGetUniformLocation(shader->ID, "diffuse"), diffuse.r, diffuse.g, diffuse.b);
	glm::vec3 specular = material->getSpecular();
	//std::cout << "SPECULAR FOUND?:" << glGetUniformLocation(shader->ID, "specular") << " " << specular.r << " " << specular.g << " " << specular.b << std::endl;
	glUniform3f(glGetUniformLocation(shader->ID, "specular"), specular.r, specular.g, specular.b);
	glm::vec3 emissive = material->getEmissive();
	glUniform3f(glGetUniformLocation(shader->ID, "emissive"), emissive.r, emissive.g, emissive.b);
	
	/*********************************************************************************************/

	// Keeping the window open
	while(!glfwWindowShouldClose(window)) {
		// Clearing the new frame with background colour
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Modifying matrices
		//modelMatrix = glm::rotate(modelMatrix, glm::radians(rotation), glm::vec3(0.0f, 1.0f, 0.0f));
		//viewMatrix = glm::translate(viewMatrix, glm::vec3(0.0f, 0.0f, 0.0f));
		//projectionMatrix = glm::perspective(glm::radians(45.0f), static_cast<float>(window_width / window_height), 0.1f, -1.0f);
		//
		//glUniformMatrix4fv(uniformLocation_modelMatrix, 1, GL_FALSE, &modelMatrix[0][0]);
		//glUniformMatrix4fv(uniformLocation_viewMatrix, 1, GL_FALSE, &viewMatrix[0][0]);
		//glUniformMatrix4fv(uniformLocation_projectionMatrix, 1, GL_FALSE, &projectionMatrix[0][0]);
		
		camera->registerInput(window);
		camera->updateMatrixGeometry(45.0f, 0.1f, 100.0f, shader, "cameraMatrix");

		// Drawing
		//glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture->textureID);
		glBindVertexArray(mesh->VAO);
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); // GL_POINT, GL_LINE, GL_FILL
			glDrawElements(GL_TRIANGLES, mesh->getIndicesNum(), GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);
		
		// Swapping buffers, processing window events
		glfwSwapBuffers(window);
		glfwPollEvents();

		if(glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
			glfwSetWindowShouldClose(window, true);
		}
	}

	/*********************************************************************************************/
	// Deleting shader, mesh, camerassss
	shader->~Shader();
	material->~Material();
	mesh->~Mesh();
	camera->~Camera();

	// Terminating GLFW
	glfwTerminate();

	return EXIT_SUCCESS;
}
