#pragma once

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

#include <assimp/Importer.hpp>      
#include <assimp/scene.h>           
#include <assimp/postprocess.h> 

#include <iostream>
#include <vector>

#include "Material.h"
#include "Texture.h"

class Mesh {
private:
	std::string path;

	std::vector<float> vertices; // convert to glm::vec3 if possible
	std::vector<float> vertex_normals;
	std::vector<float> vertex_textures;
	std::vector<unsigned int> vertex_indices;

	// Bounding Box stores {x_min, x_max, y_min, y_max, z_min, z_max}
	std::vector<float> boundingBox;

public:
	Mesh(char* path, Material* material, Texture* texture);
	~Mesh();

	GLuint VAO;
	GLuint VBO_vertex;
	GLuint VBO_normal;
	GLuint VBO_texture;
	GLuint EBO;

	void setupBuffers();
	void updateBuffers();

	void loadMesh(Material* material, Texture* texture);

	std::vector<float> getBoundingBox();
	std::vector<float> getVertices();
	unsigned int getVerticesNum();
	std::vector<unsigned int> getIndices();
	unsigned int getIndicesNum();
	std::vector<float> getNormals();
	unsigned int getNormalsNum();
	std::vector<float> getTextures();
	unsigned int getTexturesNum();
};

