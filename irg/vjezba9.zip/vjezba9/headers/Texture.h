#pragma once

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

#include <assimp/Importer.hpp>      
#include <assimp/scene.h>           
#include <assimp/postprocess.h> 

#include <iostream>
#include <vector>

class Texture {
private:
public:
	GLuint textureID;
	
	Texture();
	~Texture();

	void setupTexture(unsigned char* data, int width, int height, int nrChannels);
};

