// Local Headers

// System Headers
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>

#include <assimp/Importer.hpp>      
#include <assimp/scene.h>           
#include <assimp/postprocess.h> 

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// Standard Headers
#include <iostream>
#include <cstdlib>
#include <vector>
#include "Shader.h"
#include "Mesh.h"

int width = 1280;
int height = 800;

//malo je nespretno napravljeno jer ne koristimo c++17, a treba podrzati i windows i linux,
//slobodno pozivajte new Shader(...); direktno
Shader* loadShader(char* path, char* naziv) {
	std::string sPath(path);
	std::string pathVert;
	std::string pathFrag;

	pathVert.append(path, sPath.find_last_of("\\/") + 1);
	pathFrag.append(path, sPath.find_last_of("\\/") + 1);
	if(pathFrag[pathFrag.size() - 1] == '/') {
		pathVert.append("shaders/");
		pathFrag.append("shaders/");
	} else if(pathFrag[pathFrag.size() - 1] == '\\') {
		pathVert.append("shaders\\");
		pathFrag.append("shaders\\");
	} else {
		std::cerr << "nepoznat format pozicije shadera";
		exit(1);
	}

	pathVert.append(naziv);
	pathVert.append(".vert");
	pathFrag.append(naziv);
	pathFrag.append(".frag");

	return new Shader(pathVert.c_str(), pathFrag.c_str());
}

//funkcija koja se poziva prilikom mijenjanja velicine prozora, moramo ju povecati pomocu glfwSetFramebufferSizeCallback
void framebuffer_size_callback(GLFWwindow* window, int Width, int Height) {
	width = Width;
	height = Height;

	glViewport(0, 0, width, height);
}

int main(int argc, char * argv[]) {
	/*********************************************************************************************/
	//postavljanje OpenGL konteksta, dohvacanje dostupnih OpenGL naredbi
	GLFWwindow* window;

	glfwInit();
	gladLoadGL();

	//glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	//glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
	//glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	//glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	glfwWindowHint(GLFW_DOUBLEBUFFER, GLFW_TRUE);

	window = glfwCreateWindow(width, height, "Zadatak 4", nullptr, nullptr);
	// provjeri je li se uspio napraviti prozor
	if(window == nullptr) {
		fprintf(stderr, "Failed to Create OpenGL Context");
		exit(EXIT_FAILURE);
	}
	glfwMakeContextCurrent(window);

	// dohvati sve dostupne OpenGL funkcije
	if(!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
		fprintf(stderr, "Failed to initialize GLAD");
		exit(-1);
	}
	fprintf(stderr, "OpenGL %s\n", glGetString(GL_VERSION));

	glEnable(GL_DEPTH_TEST); //ukljuci z spremnik (prikazuju se oni fragmenti koji su najblizi promatracu)
	glDepthFunc(GL_LESS);

	//glEnable(GL_CULL_FACE); //ukljuci uklanjanje straznjih poligona -- za ovaj primjer je iskljuceno
	//glCullFace(GL_BACK); 

	glClearColor(0.15, 0.1, 0.1, 1); //boja brisanja platna izmedu iscrtavanja dva okvira
	
	glfwSwapInterval(0); //ne cekaj nakon iscrtavanja (vsync)
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback); //funkcija koja se poziva prilikom mijenjanja velicine prozora

	/*********************************************************************************************/
	// SHADER
	Shader* shader = loadShader(argv[0], "shader");
	GLint uniformLocation_modelMatrix = glGetUniformLocation(shader->ID, "matrix_model");
	GLint uniformLocation_viewMatrix = glGetUniformLocation(shader->ID, "matrix_view");
	GLint uniformLocation_projectionMatrix = glGetUniformLocation(shader->ID, "matrix_projection");

	glm::mat4 matrix_identity = glm::mat4(1);
	glm::mat4 matrix_model = matrix_identity;
	glm::mat4 matrix_view = matrix_identity;
	glm::mat4 matrix_projection = matrix_identity;

	/*********************************************************************************************/
	Mesh* mesh = new Mesh(argv[0]);
	/*********************************************************************************************/
	// WINDOW LOOP
	while(glfwWindowShouldClose(window) == false) {

		//pobrisi platno
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		/****************************/
		//iscrtavanje
		glUseProgram(shader->ID);
		glUniformMatrix4fv(uniformLocation_modelMatrix, 1, GL_FALSE, &matrix_model[0][0]);
		glUniformMatrix4fv(uniformLocation_viewMatrix, 1, GL_FALSE, &matrix_view[0][0]);
		glUniformMatrix4fv(uniformLocation_projectionMatrix, 1, GL_FALSE, &matrix_projection[0][0]);

		//glViewport(0, 0, width, height);

		// DRAW POLYGON
		glBindVertexArray(mesh->VAO);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			glDrawElements(GL_TRIANGLES, mesh->getIndicesNum(), GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);

		glfwSwapBuffers(window);
		glfwPollEvents();

		if(glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
			glfwSetWindowShouldClose(window, true);	
	}

	delete shader;
	mesh->~Mesh();

	glfwTerminate();

	return EXIT_SUCCESS;
}
