#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

#include <iostream>

#include "Object.h"
#include "Shader.h"
#include "Mesh.h"

Object::Object(std::shared_ptr<Mesh> pointer_mesh, std::shared_ptr<Shader> pointer_shader) {

}
Object::~Object() {}

void Object::render(glm::mat4 matrix_view, glm::mat4 matrix_projection) {

}