//#include <glad/glad.h>
//#include <GLFW/glfw3.h>
//#include <glm/glm.hpp>
//
//#include <iostream>
//
//#include "Transform.h"
//
//Transform::Transform(glm::vec3 position = glm::vec3(0)) {
//	this->position = position;
//}
//Transform::~Transform() {
//
//}
//
//void Transform::move(glm::vec3 delta) {
//}
//void Transform::rotate(glm::vec3 rotation) {
//}
//void Transform::scale(glm::vec3 delta) {
//}
//
//glm::mat4 Transform::getMatrix_model() {
//	return matrix_model;
//}
//glm::mat4 Transform::getMatrix_view() {
//	return matrix_view;
//}
//glm::mat4 Transform::getMatrix_projection() {
//	return matrix_projection;
//}
//
