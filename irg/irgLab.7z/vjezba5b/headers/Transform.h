#pragma once

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

#include <iostream>

class Transform {
private:
	glm::vec3 position;

	glm::mat4 matrix_model;
	glm::mat4 matrix_view;
	glm::mat4 matrix_projection;

public:
	Transform(glm::vec3 position = glm::vec3(0));
	~Transform();

	void move(glm::vec3 delta);
	void rotate(glm::vec3 rotation);
	void scale(glm::vec3 delta);

	glm::mat4 getMatrix_model();
	glm::mat4 getMatrix_view();
	glm::mat4 getMatrix_projection();
};
