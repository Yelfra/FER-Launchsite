#pragma once

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

#include <iostream>

#include "Shader.h"
#include "Mesh.h"

class Object {
private:
	std::shared_ptr<Mesh> mesh;
	std::shared_ptr<Shader> shader;
	//std::shared_ptr<Material> material;

	GLint matrixID_model;
	GLint matrixID_view;
	GLint matrixID_projection;


public:
	Object(std::shared_ptr<Mesh> pointer_mesh, std::shared_ptr<Shader> pointer_shader);
	~Object();

	void render(glm::mat4 matrix_view, glm::mat4 matrix_projection);

};
